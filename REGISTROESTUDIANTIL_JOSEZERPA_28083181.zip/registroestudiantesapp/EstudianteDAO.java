import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EstudianteDAO {
    public void guardarEstudiante(Estudiante estudiante) throws SQLException {
        String sql = "INSERT INTO Estudiantes (nombre, apellido, fecha_nacimiento, estado_id, estado_civil_id, documento_id, usuario, clave) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, estudiante.getNombre());
            stmt.setString(2, estudiante.getApellido());
            stmt.setString(3, estudiante.getFechaNacimiento());
            stmt.setInt(4, estudiante.getEstadoId());
            stmt.setInt(5, estudiante.getEstadoCivilId());
            stmt.setInt(6, estudiante.getDocumentoId());
            stmt.setString(7, estudiante.getUsuario());
            stmt.setString(8, estudiante.getClave());
            stmt.executeUpdate();
        }
    }

    public void modificarEstudiante(Estudiante estudiante) throws SQLException {
        String sql = "UPDATE Estudiantes SET nombre=?, apellido=?, fecha_nacimiento=?, estado_id=?, estado_civil_id=?, documento_id=?, usuario=?, clave=? WHERE id=?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, estudiante.getNombre());
            stmt.setString(2, estudiante.getApellido());
            stmt.setString(3, estudiante.getFechaNacimiento());
            stmt.setInt(4, estudiante.getEstadoId());
            stmt.setInt(5, estudiante.getEstadoCivilId());
            stmt.setInt(6, estudiante.getDocumentoId());
            stmt.setString(7, estudiante.getUsuario());
            stmt.setString(8, estudiante.getClave());
            stmt.setInt(9, estudiante.getId());
            stmt.executeUpdate();
        }
    }

    public void eliminarEstudiante(int id) throws SQLException {
        String sql = "DELETE FROM Estudiantes WHERE id=?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }

    public Estudiante buscarEstudiantePorNombre(String nombre) throws SQLException {
        String sql = "SELECT * FROM Estudiantes WHERE nombre=?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nombre);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Estudiante(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("apellido"),
                        rs.getString("fecha_nacimiento"),
                        rs.getInt("estado_id"),
                        rs.getInt("estado_civil_id"),
                        rs.getInt("documento_id"),
                        rs.getString("usuario"),
                        rs.getString("clave")
                );
            }
        }
        return null;
    }

    public List<Estudiante> obtenerTodosLosEstudiantes() throws SQLException {
        List<Estudiante> estudiantes = new ArrayList<>();
        String sql = "SELECT * FROM Estudiantes";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                estudiantes.add(new Estudiante(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("apellido"),
                        rs.getString("fecha_nacimiento"),
                        rs.getInt("estado_id"),
                        rs.getInt("estado_civil_id"),
                        rs.getInt("documento_id"),
                        rs.getString("usuario"),
                        rs.getString("clave")
                ));
            }
        }
        return estudiantes;
    }
}
